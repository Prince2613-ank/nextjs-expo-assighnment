# Google Sign-In & FCM Demo App

This project consists of:

- A **React Web App** with Google Sign-In using Firebase Authentication.
- A **React Native App** that loads the web app using WebView and integrates Firebase Cloud Messaging (FCM) for push notifications.

---

## 📦 Project Structure

```
/web-app       => React.js app with Google Sign-In (index.js)
/mobile-app    => React Native app with WebView and FCM (App.js)
```

---

## 🖥️ React Web App – Google Sign-In

### ✅ Prerequisites

- Node.js installed
- Firebase project with authentication enabled

### 📁 Setup

1. Navigate to the web project folder:
   ```bash
   cd web-app
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Create a `.env` file in the root of `web-app`:
   ```env
   NEXT_PUBLIC_FIREBASE_API_KEY=your_api_key
   NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=your_auth_domain
   NEXT_PUBLIC_FIREBASE_PROJECT_ID=your_project_id
   NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET=your_storage_bucket
   NEXT_PUBLIC_FIREBASE_SENDER_ID=your_sender_id
   NEXT_PUBLIC_FIREBASE_APP_ID=your_app_id
   ```

4. Run the web app:
   ```bash
   npm start
   ```

5. Visit: [http://localhost:3000](http://localhost:3000)

---

## 📱 React Native App – WebView + FCM

### ✅ Prerequisites

- React Native CLI installed
- Android Studio or Xcode set up
- Firebase project with Cloud Messaging enabled

### 📁 Setup

1. Navigate to the mobile project folder:
   ```bash
   cd mobile-app
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Install native dependencies:
   ```bash
   npm install @react-native-firebase/app @react-native-firebase/messaging react-native-webview
   ```

4. Configure Firebase:
   - Add `google-services.json` (Android) or `GoogleService-Info.plist` (iOS) to the project.
   - Configure your app as per [Firebase FCM docs](https://rnfirebase.io/messaging/usage).

5. Run the app:

   **For Android:**
   ```bash
   npx react-native run-android
   ```

   **For iOS:**
   ```bash
   npx react-native run-ios
   ```

6. The app will load your web app via WebView (`http://localhost:3000` or `http://10.0.2.2:3000` for Android emulator).

7. Send push notifications using Firebase Console to test FCM functionality.

---

## ✅ Features to Test

- ✅ Google Sign-In via Firebase on Web
- ✅ Web content rendering in WebView (React Native)
- ✅ FCM Token generation and console logging
- ✅ Foreground and background push notifications

---

## 📩 Troubleshooting

- WebView not loading? Ensure the web app is running on the expected port.
- FCM not receiving messages? Make sure Firebase project permissions and emulator/device settings allow notifications.

---

## 📜 License

MIT License
