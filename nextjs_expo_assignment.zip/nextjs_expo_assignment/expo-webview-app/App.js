import React, { useEffect, useState } from 'react';
import { SafeAreaView, Platform, Alert, StyleSheet } from 'react-native';
import messaging from '@react-native-firebase/messaging';
import { WebView } from 'react-native-webview';

// Use a deployed URL or local development URL
const WEB_URL = Platform.OS === 'android' 
  ? 'http://10.0.2.2:3000'  // Android emulator localhost
  : 'http://localhost:3000'; // iOS simulator/local dev

export default function App() {
  const [fcmToken, setFcmToken] = useState('');

  useEffect(() => {
    const setupFCM = async () => {
      try {
        // Request permission (iOS only)
        await messaging().requestPermission();

        // Get FCM token
        const token = await messaging().getToken();
        setFcmToken(token);
        console.log('FCM Token:', token);

        // Foreground messages
        messaging().onMessage(remoteMessage => {
          Alert.alert(
            remoteMessage.notification?.title || 'New Message',
            remoteMessage.notification?.body || 'No body'
          );
        });

        // Background/Quit state messages
        messaging().setBackgroundMessageHandler(remoteMessage => {
          console.log('Background message:', remoteMessage);
        });

      } catch (error) {
        console.error('FCM Error:', error);
      }
    };

    setupFCM();
  }, []);

  return (
    <SafeAreaView style={styles.container}>
      <WebView 
        source={{ uri: WEB_URL }} 
        javaScriptEnabled={true}
        domStorageEnabled={true}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: Platform.OS === 'android' ? 25 : 0, // SafeArea for Android
  },
});